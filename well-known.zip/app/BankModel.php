<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankModel extends Model
{
    //
}
