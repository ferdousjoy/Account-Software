<?php

namespace App;

use Illuminate\Database\Eloquent\Model; 
class AdvancepaymentModel extends Model
{ 
    
 
    
}
