<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UpdateController extends Controller
{
        //update
        public function update(){
            return view('dashboard.update.update');
        }
    
}
