<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerModel extends Model
{
       protected $fillable=['customer','email','phone','contact','contact2','currency','BL_Ad','BL_Ad2','city','zpo','country','state','country2','state2','BL_Ad222','city3','zpo3','phone3','note','country3','state3','BL_Ad4','BL_Ad5','city5','zpo4','phone4','note2','country6','state6','BL_Ad9','zpo11','phone12','note3','Bilingadres2','contact_ship','BL_Ad33','BL_Ad5','contact_ship2'];
}
