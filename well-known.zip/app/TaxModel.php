<?php

namespace App;

use Illuminate\Database\Eloquent\Model; 
class TaxModel extends Model
{
     // protected $fillable=['account_name','description'];

}
