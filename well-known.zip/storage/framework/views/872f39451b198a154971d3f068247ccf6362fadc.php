<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/addtransaction.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h4>Add New Transaction</h4>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">
                <form method="post" id="data_form">


                    <div class="row mb-1 ml-1">
                        <div class="col-md-2 display-inline">
                            <div class="  custom-radio">
                                <input type="radio" class="custom-control-input" name="ty_p" id="customRadio1" value="0"
                                       checked="">
                                <label class="custom-control-label"
                                       for="customRadio1">Customer &nbsp;</label>
                            </div>

                            <div class="custom-radio">
                                <input type="radio" class="custom-control-input" name="ty_p" id="customRadio2"
                                       value="1">
                                <label class="custom-control-label"
                                       for="customRadio2">Supplier</label>
                            </div>

                        </div>
                        <div class="col-md-6"><input type="text" class="form-control" name="cst" id="trans-box"
                                                     placeholder="Enter Person Name or Mobile Number to search (Optional)"
                                                     autocomplete="off"/>
                            <div id="trans-box-result" class="sbox-result"></div>
                        </div>

                    </div>
                    <hr>
                    <div id="customerpanel" class="form-group row bg-blue bg-lighten-4 pb-1">

                        <div class="col-sm-4"><label for="toBizName"
                                                     class="caption col-form-label">C/o                                <span
                                        style="color: red;">*</span></label><input type="hidden" name="payer_id"
                                                                                   id="customer_id" value="0">
                            <input type="text" class="form-control required" name="payer_name" id="customer_name">
                        </div>


                        <div class="col-sm-4"><label class=" col-form-label"
                                                     for="pay_cat">To Account</label>
                            <select name="pay_acc" class="form-control">
                                <option value='1'>123456 - Sales Account</option>                            </select>


                        </div>


                        <input type="hidden" name="act" value="add_product">


                        <div class="col-sm-4"><label class="col-form-label"
                                                     for="amount">Amount</label>
                            <input type="number" placeholder="Amount"
                                   class="form-control margin-bottom  required" name="amount" value="0">
                        </div>
                    </div>
                    <div class="form-group row ">
                        <div class="col-sm-4"><label class="col-form-label"
                                                     for="date">Date</label>
                            <input type="text" class="form-control required"
                                   name="date" data-toggle="datepicker"
                                   autocomplete="false">
                        </div>


                        <div class="col-sm-4"><label class="col-form-label"
                                                     for="product_price">Type</label>

                            <select name="pay_type" class="form-control">
                                <option value="Income"
                                        selected>Income / Credit</option>
                                <option value="Expense">Expense / Debit</option>

                            </select>


                        </div>


                        <div class="col-sm-4"><label class="col-form-label"
                                                     for="pay_cat">Category</label>
                            <select name="pay_cat" class="form-control">
                                <option value='Income'>Income</option><option value='Expenses'>Expenses</option><option value='Other'>Other</option>                            </select>


                        </div>


                    </div>
                    <div class="form-group row bg-blue bg-lighten-4 pb-1">

                        <div class="col-sm-4"><label class="col-form-label"
                                                     for="product_price">Method </label>

                            <select name="paymethod" class="form-control">
                                <option value="Cash" selected>Cash</option>
                                <option value="Card">Card</option>
                                <option value="Cheque">Cheque</option>
                                <option value="Bank">Bank</option>
                                <option value="Other">Other</option>
                            </select>


                        </div>


                        <div class="col-sm-8"><label
                                    class="col-form-label">Note</label>
                            <input type="text" placeholder="Note"
                                   class="form-control" name="note">
                        </div>
                    </div>
                    <!---- Dual -->
                    
                    <div class="form-group row">


                        <div class="col-sm-4">
                            <input type="submit" id="submit-data" class="btn btn-success btn-lg margin-bottom"
                                   value="Add transaction"
                                   data-loading-text="Adding...">
                            <input type="hidden" value="transactions/save_trans" id="action-url">
                        </div>
                    </div>


                </form>
            </div>
        </div>
        <script type="text/javascript">
            $("#trans-box").keyup(function () {
                $.ajax({
                    type: "GET",
                    url: baseurl + 'search_products/party_search',
                    data: 'keyword=' + $(this).val() + '&ty=' + $('input[name=ty_p]:checked').val(),
                    beforeSend: function () {
                        $("#trans-box").css("background", "#FFF url(" + baseurl + "assets/custom/load-ring.gif) no-repeat 165px");
                    },
                    success: function (data) {
                        $("#trans-box-result").show();
                        $("#trans-box-result").html(data);
                        $("#trans-box").css("background", "none");

                    }
                });
            });
        </script>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>